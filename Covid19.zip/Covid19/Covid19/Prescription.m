//
//  Prescription.m
//  Covid19
//
//  Created by zhenbo song on 4/10/21.
//  Copyright © 2021 zhenbo song. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Prescription.h"
#import "TableViewCell.h"

@interface Prescription()<UITableViewDataSource, UITableViewDelegate, CellDelegate>

@property(nonatomic,strong,readwrite) UITableView *tableView;
@property(nonatomic,strong,readwrite) UIView *UPView;
@property(nonatomic,strong,readwrite) UIButton *AddButton;
@property(nonatomic,strong,readwrite) NSMutableArray *dataPlaceArray;
@property(nonatomic,strong,readwrite) NSMutableArray *dataTimeArray;
@property(nonatomic,strong,readwrite) NSString *PlaceString;
@property(nonatomic,strong,readwrite) NSString *TimeString;
@property(nonatomic,strong,readwrite) UITextField *AddPlace;
@property(nonatomic,strong,readwrite) UITextField *AddTime;

@end

@implementation Prescription

-(instancetype) init{
    self = [super init];
    if (self) {
        _dataPlaceArray = @[].mutableCopy;
        [_dataPlaceArray addObject:@"PID:111002"];
        
        
        _dataTimeArray = @[].mutableCopy;
        [_dataTimeArray addObject:@"2020/02/05"];
    }
    return self;
}


-(void) viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor lightGrayColor];

    UILabel *title = [[UILabel alloc]init];
    title.text = @"Prescription";
    title.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = title;
    
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0,400,self.view.frame.size.width,self.view.frame.size.height -400)];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    
    _UPView = [[UIView alloc]initWithFrame:CGRectMake(0, 88, self.view.frame.size.width, 320)];
    _UPView.backgroundColor = [UIColor whiteColor];
    
    _AddButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _AddButton.frame = CGRectMake(280, 10, 120, 80);
    [_AddButton setTitle:@"Add Prescription" forState:UIControlStateNormal];
    [_AddButton addTarget:self action:@selector(AddBtnOnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    _AddPlace = [[UITextField alloc]init];
    _AddPlace.frame = CGRectMake(15, 30, 200, 160);
    _AddPlace.placeholder = @"Enter Prescription";
    _AddPlace.borderStyle = UITextBorderStyleRoundedRect;

    _AddTime = [[UITextField alloc]init];
    _AddTime.frame = CGRectMake(15, 250, 150, 40);
    _AddTime.placeholder = @"Enter Time";
    _AddTime.borderStyle = UITextBorderStyleRoundedRect;
    
    [_UPView addSubview:_AddButton];
    [_UPView addSubview:_AddPlace];
    [_UPView addSubview:_AddTime];
    [self.view addSubview:_tableView];
    [self.view addSubview:_UPView];
    
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataPlaceArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id"];
    if (!cell) {
        cell = [[TableViewCell alloc] initWithStyle: UITableViewCellStyleValue1 reuseIdentifier:@"id"];
        cell.delegate = self;
        
    }
    NSString *Place = [self.dataPlaceArray objectAtIndex:indexPath.row];
    NSString *Time = [self.dataTimeArray objectAtIndex:indexPath.row];
    
    
    [cell layoutTableViewCell:Place Time:Time];
    return cell;
}

-(void) tabelViewCell: (UITableViewCell *) tableViewCell deleteOnClicked:(UIButton *) deleteButton
{
    [_dataPlaceArray removeLastObject];
    [_dataTimeArray removeLastObject];
    
    [self.tableView deleteRowsAtIndexPaths:@[[self.tableView indexPathForCell:tableViewCell]] withRowAnimation:UITableViewRowAnimationAutomatic];
}

-(void) AddBtnOnClicked
{

    
    //test
    [_dataPlaceArray addObject:_AddPlace.text];
    [_dataTimeArray addObject:_AddTime.text];

    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:_dataPlaceArray.count-1 inSection:0];
    [_tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];

}


@end
