//
//  One.m
//  Covid19
//
//  Created by zhenbo song on 4/9/21.
//  Copyright © 2021 zhenbo song. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TabBarViewController.h"
#import "Symptom.h"
#import "NewViewController.h"
#import "TripViewController.h"
#import "DoctorViewController.h"
#import "ActivityViewController.h"
#import "NewActiViewController.h"

@interface TabBarViewController()

@end

@implementation TabBarViewController

-(void) loadView
{
    [super loadView];
    
    
    
}

-(void) viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    Symptom *Manage = [[Symptom alloc]init];
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController: Manage];
    
    NewViewController *controller1 = [[NewViewController alloc]init];
    controller1.tabBarItem.title = @"News";
    
    TripViewController *controller2 = [[TripViewController alloc]init];
    controller2.tabBarItem.title = @"Trip";
    
    DoctorViewController *controller3 = [[DoctorViewController alloc]init];
    controller3.tabBarItem.title = @"Doctor";
    
//    ActivityViewController *controller4 = [[ActivityViewController alloc]init];
//    controller4.tabBarItem.title = @"Activity";
    
    NewActiViewController *controller4 = [[NewActiViewController alloc]init];
    controller4.tabBarItem.title = @"Activity";
    
    navigationController.tabBarItem.title = @"Manage";
    
    [self setViewControllers:@[controller1,controller2,controller3,controller4,navigationController]];
   
    
    
}

@end
