//
//  Medicine.h
//  Covid19
//
//  Created by zhenbo song on 4/10/21.
//  Copyright © 2021 zhenbo song. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Medicine : UIViewController
{

}

@end
