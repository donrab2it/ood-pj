//
//  ViewController.h
//  Covid19
//
//  Created by zhenbo song on 4/9/21.
//  Copyright © 2021 zhenbo song. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UILabel* _GroupName;
    UILabel* _GroupMember;
    UILabel* _MemberOne;
    UILabel* _MemberTwo;
    UILabel* _MemberThree;
    //UserName TextBox
    //PassWord TextBox
    //Login Button
    //Register Button
    UILabel* _lbUserName;
    UILabel* _lbPassWord;
    UITextField* _tfUserName;
    UITextField* _tfPassWord;
    UIButton* _btLogin;
    UIButton* _btRegister;
}

@end

