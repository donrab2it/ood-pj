//
//  ActivityViewController.m
//  Covid19
//
//  Created by zhenbo song on 4/12/21.
//  Copyright © 2021 zhenbo song. All rights reserved.
//

#import "ActivityViewController.h"
#import "TableViewCell.h"

@interface ActivityViewController ()<UITableViewDataSource, UITableViewDelegate, CellDelegate>

@property(nonatomic,strong,readwrite) UITableView *tableView;
@property(nonatomic,strong,readwrite) UIView *UPView;
@property(nonatomic,strong,readwrite) UIButton *AddButton;
@property(nonatomic,strong,readwrite) NSMutableArray *dataPlaceArray;
@property(nonatomic,strong,readwrite) NSMutableArray *dataTimeArray;
@property(nonatomic,strong,readwrite) NSString *PlaceString;
@property(nonatomic,strong,readwrite) NSString *TimeString;
@property(nonatomic,strong,readwrite) UITextField *AddPlace;
@property(nonatomic,strong,readwrite) UITextField *AddTime;

@end

@implementation ActivityViewController

-(instancetype) init{
    self = [super init];
    if (self) {
        _dataPlaceArray = @[].mutableCopy;
        [_dataPlaceArray addObject:@"61/min"];
        [_dataPlaceArray addObject:@"74/min"];
        [_dataPlaceArray addObject:@"120/min"];
        [_dataPlaceArray addObject:@"55/min"];
        
        _dataTimeArray = @[].mutableCopy;
        [_dataTimeArray addObject:@"2020/02/05"];
        [_dataTimeArray addObject:@"2020/05/12"];
        [_dataTimeArray addObject:@"2020/06/01"];
        [_dataTimeArray addObject:@"2020/09/21"];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0,100,self.view.frame.size.width,self.view.frame.size.height -100)];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    
    _UPView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 100)];
    _UPView.backgroundColor = [UIColor whiteColor];
    
    _AddButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _AddButton.frame = CGRectMake(300, 30, 100, 80);
    [_AddButton setTitle:@"Add Activity" forState:UIControlStateNormal];
    [_AddButton addTarget:self action:@selector(AddBtnOnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    _AddPlace = [[UITextField alloc]init];
    _AddPlace.frame = CGRectMake(15, 50, 120, 40);
    _AddPlace.placeholder = @"Enter HeartRate";
    _AddPlace.borderStyle = UITextBorderStyleRoundedRect;

    _AddTime = [[UITextField alloc]init];
    _AddTime.frame = CGRectMake(160, 50, 120, 40);
    _AddTime.placeholder = @"Enter Time";
    _AddTime.borderStyle = UITextBorderStyleRoundedRect;
    
    [_UPView addSubview:_AddButton];
    [_UPView addSubview:_AddPlace];
    [_UPView addSubview:_AddTime];
    [self.view addSubview:_tableView];
    [self.view addSubview:_UPView];
    
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataPlaceArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"id"];
    if (!cell) {
        cell = [[TableViewCell alloc] initWithStyle: UITableViewCellStyleValue1 reuseIdentifier:@"id"];
        cell.delegate = self;
        
    }
    NSString *Place = [self.dataPlaceArray objectAtIndex:indexPath.row];
    NSString *Time = [self.dataTimeArray objectAtIndex:indexPath.row];
    
    
    [cell layoutTableViewCell:Place Time:Time];
    return cell;
}

-(void) tabelViewCell: (UITableViewCell *) tableViewCell deleteOnClicked:(UIButton *) deleteButton
{
    [_dataPlaceArray removeLastObject];
    [_dataTimeArray removeLastObject];
    
    [self.tableView deleteRowsAtIndexPaths:@[[self.tableView indexPathForCell:tableViewCell]] withRowAnimation:UITableViewRowAnimationAutomatic];
}

-(void) AddBtnOnClicked
{

    
    //test
    [_dataPlaceArray addObject:_AddPlace.text];
    [_dataTimeArray addObject:_AddTime.text];

    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:_dataPlaceArray.count-1 inSection:0];
    [_tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];

}




@end
