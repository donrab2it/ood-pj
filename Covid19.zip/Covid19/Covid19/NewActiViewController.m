//
//  NewActiViewController.m
//  Covid19
//
//  Created by zhenbo song on 4/13/21.
//  Copyright © 2021 zhenbo song. All rights reserved.
//

#import "NewActiViewController.h"

@interface NewActiViewController ()

@property(nonatomic,strong,readwrite) UIButton *RefreshButton;
@property(nonatomic,strong,readwrite) UILabel *HeartRate;
@property(nonatomic,strong,readwrite) UILabel *BloodPressureRate;
@property(nonatomic,strong,readwrite) UILabel *Weight;
@property(nonatomic,strong,readwrite) UILabel *Height;

@property(nonatomic,strong,readwrite) UILabel *dataHeartRate;
@property(nonatomic,strong,readwrite) UILabel *dataBloodPressureRate;
@property(nonatomic,strong,readwrite) UILabel *dataWeight;
@property(nonatomic,strong,readwrite) UILabel *dataHeight;


@property(nonatomic,strong,readwrite) NSString *HR;
@property(nonatomic,strong,readwrite) NSString *BP;
@property(nonatomic,strong,readwrite) NSString *W;
@property(nonatomic,strong,readwrite) NSString *H;


//@property(nonatomic,strong,readwrite)

@end

@implementation NewActiViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    _RefreshButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _RefreshButton.frame = CGRectMake(170, 50, 80, 40);
    [_RefreshButton setTitle:@"Refresh" forState:UIControlStateNormal];
    _RefreshButton.titleLabel.font = [UIFont systemFontOfSize:20];
    [_RefreshButton addTarget:self action:@selector(RefreshOnclicked) forControlEvents:UIControlEventTouchUpInside];
    
    
    _HeartRate = [[UILabel alloc]init];
    _HeartRate.frame = CGRectMake(15, 150, 135, 40);
    _HeartRate.textAlignment = NSTextAlignmentCenter;
    _HeartRate.text = @"HeartRate:";
    _HeartRate.font = [UIFont systemFontOfSize:25];

    
    _BloodPressureRate = [[UILabel alloc]init];
    _BloodPressureRate.frame = CGRectMake(15, 250, 220, 40);
    _BloodPressureRate.textAlignment = NSTextAlignmentCenter;
    _BloodPressureRate.text = @"BloodPressureRate:";
    _BloodPressureRate.font = [UIFont systemFontOfSize:25];

    
    _Weight = [[UILabel alloc]init];
    _Weight.frame = CGRectMake(15, 350, 100, 40);
    _Weight.textAlignment = NSTextAlignmentCenter;
    _Weight.text = @"Weight:";
    _Weight.font = [UIFont systemFontOfSize:25];

    
    _Height = [[UILabel alloc]init];
    _Height.frame = CGRectMake(15, 450, 100, 40);
    _Height.textAlignment = NSTextAlignmentCenter;
    _Height.text = @"Height:";
    _Height.font = [UIFont systemFontOfSize:25];
    
    [self.view addSubview:_RefreshButton];
    [self.view addSubview:_HeartRate];
    [self.view addSubview:_BloodPressureRate];
    [self.view addSubview:_Weight];
    [self.view addSubview:_Height];
    
    _HR = @"60";
    _BP = @"60";
    _W = @"60";
    _H = @"180";
    
    _dataHeartRate = [[UILabel alloc]init];
    _dataHeartRate.frame = CGRectMake(330, 150, 50, 40);
    _dataHeartRate.textAlignment = NSTextAlignmentCenter;
    _dataHeartRate.text = _HR;
    _dataHeartRate.font = [UIFont systemFontOfSize:25];

    
    _dataBloodPressureRate = [[UILabel alloc]init];
    _dataBloodPressureRate.frame = CGRectMake(330, 250, 50, 40);
    _dataBloodPressureRate.textAlignment = NSTextAlignmentCenter;
    _dataBloodPressureRate.text = _BP;
    _dataBloodPressureRate.font = [UIFont systemFontOfSize:25];

    
    _dataWeight = [[UILabel alloc]init];
    _dataWeight.frame = CGRectMake(330, 350, 50, 40);
    _dataWeight.textAlignment = NSTextAlignmentCenter;
    _dataWeight.text = _W;
    _dataWeight.font = [UIFont systemFontOfSize:25];

    
    _dataHeight = [[UILabel alloc]init];
    _dataHeight.frame = CGRectMake(330, 450, 50, 40);
    _dataHeight.textAlignment = NSTextAlignmentCenter;
    _dataHeight.text = _H;
    _dataHeight.font = [UIFont systemFontOfSize:25];
    
    [self.view addSubview:_dataHeartRate];
    [self.view addSubview:_dataBloodPressureRate];
    [self.view addSubview:_dataWeight];
    [self.view addSubview:_dataHeight];
 
    
}

-(void)RefreshOnclicked
{
    int num1 = 60+ arc4random_uniform(80);
    int num2 = 70+ arc4random_uniform(100);
    int num3 = 40+ arc4random_uniform(60);
    int num4 = 150 + arc4random_uniform(40);
    _HR = [NSString stringWithFormat:@"%.d",num1];
    _BP = [NSString stringWithFormat:@"%.d",num2];
    _W = [NSString stringWithFormat:@"%.d",num3];
    _H = [NSString stringWithFormat:@"%.d",num4];
    _dataHeartRate.text = _HR;
    _dataBloodPressureRate.text = _BP;
    _dataWeight.text = _W;
    _dataHeight.text = _H;
}

@end
