//
//  TableViewCell.m
//  Covid19
//
//  Created by zhenbo song on 4/10/21.
//  Copyright © 2021 zhenbo song. All rights reserved.
//

#import "TableViewCell.h"

@interface TableViewCell()

@property (nonatomic, strong, readwrite) UILabel *placeLabel;
@property (nonatomic, strong, readwrite) UILabel *timeLabel;
@property (nonatomic, strong, readwrite) UIButton *deleteButton;

@end

@implementation TableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(nullable NSString *)reuseIdentifier{
    self = [super initWithStyle: style reuseIdentifier: reuseIdentifier];
    if (self) {
        [self.contentView addSubview:({
            self.placeLabel = [[UILabel alloc] initWithFrame:CGRectMake(20,15,100,50)];
            
            self.placeLabel.font = [UIFont systemFontOfSize:20];
            self.placeLabel.textColor = [UIColor blackColor];
            self.placeLabel;
        })];
        
        [self.contentView addSubview:({
            self.timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(200,15,150,30)];
            
            self.timeLabel.font = [UIFont systemFontOfSize:20];
            self.timeLabel.textColor = [UIColor grayColor];
            self.timeLabel;
        })];
        
        [self.contentView addSubview:({
            self.deleteButton = [[UIButton alloc] initWithFrame:CGRectMake(330,55,20,20)];
            [self.deleteButton setTitle:@"X" forState:UIControlStateNormal];
            self.deleteButton.backgroundColor = [UIColor lightGrayColor];
            [self.deleteButton addTarget:self action:@selector(deleteButtonOnClicked) forControlEvents:UIControlEventTouchUpInside];
            self.deleteButton;
        })];
    }
    return self;
}
-(void) deleteButtonOnClicked
{

    
    if (self.delegate && [self.delegate respondsToSelector:@selector(tabelViewCell:deleteOnClicked:)]) {
        [self.delegate tabelViewCell:self deleteOnClicked:self.deleteButton];
    }
}

-(void) layoutTableViewCell:(NSString *)Place Time: (NSString *) Time
{
    self.placeLabel.text = Place;
    self.timeLabel.text = Time;
}


@end
