//
//  TableViewCell.h
//  Covid19
//
//  Created by zhenbo song on 4/10/21.
//  Copyright © 2021 zhenbo song. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol CellDelegate <NSObject>

-(void) tabelViewCell: (UITableViewCell *) tableViewCell deleteOnClicked:(UIButton *) deleteButton;


@end

@interface TableViewCell : UITableViewCell

@property(nonatomic,weak,readwrite) id<CellDelegate> delegate;

-(void) layoutTableViewCell:(NSString *)Place Time: (NSString *) Time;

@end

NS_ASSUME_NONNULL_END
