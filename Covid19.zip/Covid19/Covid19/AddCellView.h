//
//  AddCellView.h
//  Covid19
//
//  Created by zhenbo song on 4/11/21.
//  Copyright © 2021 zhenbo song. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol AddCellDelegate <NSObject>

-(void) AddtabelViewCell: (UIView *) AddtableViewCell AddOnClicked:(UIButton *) AddButton;


@end

@interface AddCellView : UIView

typedef void(^sendValue)(NSString *Placetext,NSString *Timetext);

@property(nonatomic,weak,readwrite) id<AddCellDelegate> delegate1;

-(void) showAddView : (CGPoint) point;

-(void) sendString:(sendValue)block;

@end

NS_ASSUME_NONNULL_END
