//
//  AddCellView.m
//  Covid19
//
//  Created by zhenbo song on 4/11/21.
//  Copyright © 2021 zhenbo song. All rights reserved.
//

#import "AddCellView.h"
#import "TripViewController.h"

@interface AddCellView()


@property(nonatomic,strong,readwrite) UIView *backgroundView;
@property(nonatomic,strong,readwrite) UIView *AddView;
@property(nonatomic,strong,readwrite) UIButton *AddButton;
@property(nonatomic,strong,readwrite) UITextField *AddPlace;
@property(nonatomic,strong,readwrite) UITextField *AddTime;
@property(nonatomic,strong,readwrite) NSString *PlaceString;
@property(nonatomic,strong,readwrite) NSString *TimeString;

@end

@implementation AddCellView

-(instancetype) initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:({
            _backgroundView = [[UIView alloc] initWithFrame:self.bounds];
            _backgroundView.backgroundColor = [UIColor blackColor];
            _backgroundView.alpha = 0.5;
            [_backgroundView addGestureRecognizer:({
                UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dismissDeleteView)];
                tapGesture;
            })];
            _backgroundView;
        })];
        
        [self addSubview:({
            _AddView = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            _AddView.frame = CGRectMake(20, 50, 40, 40);
            _AddView.backgroundColor = [UIColor whiteColor];
            _AddView;
        })];
        
        
        [_AddView addSubview:({
            _AddButton = [[UIButton alloc] initWithFrame:CGRectMake(150, 230, 50, 40)];
            [_AddButton setTitle:@"Done" forState:UIControlStateNormal];
            [_AddButton addTarget:self action:@selector(_clickButton) forControlEvents:UIControlEventTouchUpInside];
            _AddButton.backgroundColor = [UIColor blackColor];
            _AddButton;
        })];
        
        
        [_AddView addSubview:({
            _AddPlace = [[UITextField alloc]init];
            _AddPlace.frame = CGRectMake(90, 50, 180, 40);
            _AddPlace.placeholder = @"Enter Place";
            _AddPlace.borderStyle = UITextBorderStyleRoundedRect;
            _AddPlace;
        })];
        
        [_AddView addSubview:({
            _AddTime = [[UITextField alloc]init];
            _AddTime.frame = CGRectMake(90, 150, 180, 40);
            _AddTime.placeholder = @"Enter Time";
            _AddTime.borderStyle = UITextBorderStyleRoundedRect;
            _AddTime;
        })];
    }
    return self;
}

-(void) showAddView : (CGPoint) point
{
    
    [[UIApplication sharedApplication].windows.lastObject addSubview:self];
    
    [UIView animateWithDuration:1.f delay:0.f usingSpringWithDamping:0.5 initialSpringVelocity:0.5 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        self.AddView.frame = CGRectMake((self.bounds.size.width - 350)/2, (self.bounds.size.height - 300)/2, 350, 300);
    } completion:^(BOOL finished){
        
    }];
}

-(void) dismissDeleteView
{
    [self removeFromSuperview];
}

-(void) sendString:(sendValue)block
{
    block(_PlaceString, _TimeString);
}

-(void) _clickButton
{
    _PlaceString = _AddPlace.text;
    _TimeString = _AddTime.text;
    
    if (self.delegate1 && [self.delegate1 respondsToSelector:@selector(AddtabelViewCell:AddOnClicked:)]) {
        [self.delegate1 AddtabelViewCell: self AddOnClicked: _AddButton];
    }
    [self removeFromSuperview];
}


@end
