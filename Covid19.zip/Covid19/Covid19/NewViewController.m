//
//  NewViewController.m
//  Covid19
//
//  Created by zhenbo song on 4/10/21.
//  Copyright © 2021 zhenbo song. All rights reserved.
//

#import "NewViewController.h"
#import <WebKit/WebKit.h>

@interface NewViewController ()
@property (nonatomic, strong, readwrite) WKWebView *webView;
@end

@implementation NewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.view addSubview:({
        self.webView = [[WKWebView alloc] initWithFrame:CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height-88)];
        self.webView;
    })];
    
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"https://www.webmd.com/"]]];
}

@end
