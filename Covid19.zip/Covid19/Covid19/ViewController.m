//
//  ViewController.m
//  Covid19
//
//  Created by zhenbo song on 4/9/21.
//  Copyright © 2021 zhenbo song. All rights reserved.
//
#import "ViewController.h"
#import "TabBarViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"covid19.png"]];
    
    //GroupName and MemberName:
    _GroupName = [[UILabel alloc]init];
    _GroupName.frame = CGRectMake(120, 80, 180, 40);
    _GroupName.textAlignment = NSTextAlignmentCenter;
    _GroupName.text = @"Covid-19";
    _GroupName.font = [UIFont systemFontOfSize:40];
    _GroupName.textColor = [UIColor whiteColor];
    
    _GroupMember = [[UILabel alloc]init];
    _GroupMember.frame = CGRectMake(150, 160, 115, 40);
    _GroupMember.textAlignment = NSTextAlignmentCenter;
    _GroupMember.text = @"Team 8";
    _GroupMember.font = [UIFont systemFontOfSize:25];
    _GroupMember.textColor = [UIColor whiteColor];
    
//    _MemberOne = [[UILabel alloc]init];
//    _MemberOne.frame = CGRectMake(150, 200, 100, 40);
//    _MemberOne.textAlignment = NSTextAlignmentCenter;
//    _MemberOne.text = @"XiJie Wu";
//    _MemberOne.font = [UIFont systemFontOfSize:20];
//    _MemberOne.textColor = [UIColor whiteColor];
    
    //UserName label init
    _lbUserName = [[UILabel alloc]init];
    _lbUserName.frame = CGRectMake(40, 500, 120, 40);
    _lbUserName.text = @"UserName:";
    _lbUserName.font = [UIFont systemFontOfSize:20];
    _lbUserName.textAlignment = NSTextAlignmentLeft;
    //Password label init
    _lbPassWord = [[UILabel alloc]init];
    _lbPassWord.frame = CGRectMake(40, 580, 120, 40);
    _lbPassWord.text = @"PassWord:";
    _lbPassWord.font = [UIFont systemFontOfSize:20];
    _lbPassWord.textAlignment = NSTextAlignmentLeft;
    //UserName text box
    _tfUserName = [[UITextField alloc]init];
    _tfUserName.frame = CGRectMake(180, 500, 180, 40);
    _tfUserName.placeholder = @"Enter UserName";
    _tfUserName.borderStyle = UITextBorderStyleRoundedRect;
    //PassWord text box
    _tfPassWord = [[UITextField alloc]init];
    _tfPassWord.frame = CGRectMake(180, 580, 180, 40);
    _tfPassWord.placeholder = @"Enter PassWord";
    _tfPassWord.borderStyle = UITextBorderStyleRoundedRect;
    _tfPassWord.secureTextEntry = YES;
    //Login and register button
    _btLogin = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _btLogin.frame = CGRectMake(170, 700, 80, 40);
    _btLogin.titleLabel.font = [UIFont systemFontOfSize:20];
    [_btLogin setTitle:@"Login" forState:UIControlStateNormal];
    [_btLogin addTarget:self action:@selector(LoginButtonOnClicked:) forControlEvents:UIControlEventTouchUpInside];
    
//    _btRegister = [UIButton buttonWithType:UIButtonTypeRoundedRect];
//    _btRegister.frame = CGRectMake(200, 680, 80, 40);
//    [_btRegister setTitle:@"Regist" forState:UIControlStateNormal];
//    [_btRegister addTarget:self action:@selector(RegisterButtonOnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:_MemberOne];
    [self.view addSubview:_GroupMember];
    [self.view addSubview:_GroupName];
    [self.view addSubview:_lbUserName];
    [self.view addSubview:_lbPassWord];
    [self.view addSubview:_tfUserName];
    [self.view addSubview:_tfPassWord];
    [self.view addSubview:_btLogin];
    [self.view addSubview:_btRegister];
    
}

-(void) LoginButtonOnClicked:(UIButton *)sender
{
    NSString* strName = @"User1";
    NSString* strPass = @"12345";
    NSString* strTextName = _tfUserName.text;
    NSString* strTextPass = _tfPassWord.text;
    if ([strName isEqualToString:strTextName] && [strPass isEqualToString:strTextPass]) {
        
        TabBarViewController *TargetController = [[TabBarViewController alloc]init];
        
        [self.navigationController pushViewController: TargetController animated:YES];
    }
    else
    {
        UIAlertController* alView = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Wrong PassWord/UserName" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *conform = [UIAlertAction actionWithTitle:@"Conform" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                NSLog(@"Conform");
            }];
         
        [alView addAction:conform];
        [self presentViewController:alView animated:YES completion:nil];
    }
}
-(void) RegisterButtonOnClicked
{
    
}

-(void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [_tfPassWord resignFirstResponder];
    [_tfUserName resignFirstResponder];
}

-(void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

@end
